#ifndef INFL_FIELD_H
#define INFL_FIELD_H

#include <glib-object.h>
#include "influence-cell.h"

G_BEGIN_DECLS

#define INFL_TYPE_FIELD (infl_field_get_type())

#define INFL_FIELD(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), INFL_TYPE_FIELD, InflField))
#define INFL_IS_FIELD(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), INFL_TYPE_FIELD))
#define INFL_FIELD_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), INFL_TYPE_FIELD, InflFieldClass))
#define INFL_IS_FIELD_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), INFL_TYPE_FIELD))
#define INFL_FIELD_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), INFL_TYPE_FIELD, InflFieldClass))

typedef struct _InflField        InflField;
typedef struct _InflFieldClass   InflFieldClass;

GType infl_field_get_type(void);

InflField *infl_field_new(GPtrArray *arr, int w, int h);

InflCell *infl_field_get_cell(InflField *field, int x, int y);
GPtrArray *infl_field_get_player_cells(InflField* field, int player);

int infl_field_get_width(InflField *field);
int infl_field_get_height(InflField *field);
void infl_field_get_size(InflField *field, int *w, int *h);

void infl_field_display(InflField *field);

G_END_DECLS

#endif /* INFL_FIELD_H */

