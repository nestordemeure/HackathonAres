#ifndef INFL_CLIENT_H
#define INFL_CLIENT_H

#include <glib-object.h>
#include "influence-field.h"

G_BEGIN_DECLS

/**
 * InflClientStatus:
 * @INFL_CLIENT_CONNECTION_LOST: Problème de réseau.
 * @INFL_CLIENT_ONGOING: Partie en cours.
 * @INFL_CLIENT_VICTORY: Victoire du client.
 * @INFL_CLIENT_DEFEAT: Défaite du client.
 * 
 * Cette énumération est utilisée par la méthode infl_client_get_status() pour
 * indiquer le statut du client. Le serveur ne réagira pas si le statut est
 * différent de @INFL_CLIENT_ONGOING.
 */
typedef enum {
    INFL_CLIENT_CONNECTION_LOST,
    INFL_CLIENT_ONGOING,
    INFL_CLIENT_VICTORY,
    INFL_CLIENT_DEFEAT
} InflClientStatus;

#define INFL_TYPE_CLIENT (infl_client_get_type())

#define INFL_CLIENT(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), INFL_TYPE_CLIENT, InflClient))
#define INFL_IS_CLIENT(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), INFL_TYPE_CLIENT))
#define INFL_CLIENT_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), INFL_TYPE_CLIENT, InflClientClass))
#define INFL_IS_CLIENT_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), INFL_TYPE_CLIENT))
#define INFL_CLIENT_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), INFL_TYPE_CLIENT, InflClientClass))

typedef struct _InflClient        InflClient;
typedef struct _InflClientClass   InflClientClass;

GType infl_client_get_type(void);

InflClient *infl_client_new(void);

int infl_client_connect(InflClient *client, const gchar *address, const gchar *team_name);
void infl_client_connect_err(InflClient *client, const gchar *address, const gchar *team_name, GError **err);

InflClientStatus infl_client_get_status(InflClient *client);

InflField *infl_client_attack(InflClient *client, int origin_x, int origin_y, int x, int y);
int infl_client_end_attacks(InflClient *client);

void infl_client_add_units(InflClient* client, InflCell* c, int count);
void infl_client_add_unit_list(InflClient *client, InflCell **units, int n);
int infl_client_get_remaining_units(InflClient *client);
InflField *infl_client_end_adding_units(InflClient *client);

InflField *infl_client_get_map(InflClient *client);

InflField* infl_client_next_round(InflClient* client);

GPtrArray *infl_client_get_my_cells_arr(InflClient *client);
void infl_client_get_my_cells(InflClient *client, InflCell ***cells, int *n);
int infl_client_get_number(InflClient *client);

G_END_DECLS

#endif /* INFL_CLIENT_H */
