#ifndef INFL_CELL_H
#define INFL_CELL_H

#include <glib-object.h>

G_BEGIN_DECLS

#define INFL_TYPE_CELL (infl_cell_get_type())

#define INFL_CELL(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), INFL_TYPE_CELL, InflCell))
#define INFL_IS_CELL(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), INFL_TYPE_CELL))
#define INFL_CELL_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), INFL_TYPE_CELL, InflCellClass))
#define INFL_IS_CELL_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), INFL_TYPE_CELL))
#define INFL_CELL_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), INFL_TYPE_CELL, InflCellClass))

typedef struct _InflCell        InflCell;
typedef struct _InflCellClass   InflCellClass;

GType infl_cell_get_type(void);

InflCell *infl_cell_new(int x, int y);

int infl_cell_get_x(InflCell *cell);
int infl_cell_get_y(InflCell *cell);
int infl_cell_get_owner(InflCell *cell);
int infl_cell_get_unit_count(InflCell *cell);

void infl_cell_set_owner(InflCell *cell, int owner);
void infl_cell_set_unit_count(InflCell *cell, int count);

G_END_DECLS

#endif /* INFL_CELL_H */

